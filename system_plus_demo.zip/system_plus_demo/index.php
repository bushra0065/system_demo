<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Document</title>
</head>
<body>
	
<div class="container wrapper">
	<div class="row">
       <div class="heading">
       	<h1>Comments</h1>
       </div>

       <div class="col-md-6 first_comment">
       	<img class="float" src="images/user1.png">
       	<div class="handler">
       	   <h4>Maria</h4>
       	   <p>I was very glad to have you after such a long time. Can you plan a meetup? Maybe this weekend?</p>
           
           <div class="add">
           	<img src="images/unlike.svg" onclick="changeImg()" id="myImg">
           <span onclick="onButtonClick()">Reply</span>
           <form action="index.php" method="post">

           	<div  class="hide" id="textInput" >

           <input  type="text" name="comment" class="commentt"   placeholder="Write Your Comment">
           <button class="submit" type="submit" name="submit"><img  src="images/send.svg"></button>
           </div>
           </div>

           </form>

           </div>
       </div>

        <div class="col-md-6 scnd_comment">
       	<img class="float" src="images/user2.png">
       	<div class="handler">
       	<h4>Tania</h4>
       	   <p>Hey bud, welcome back to home. It's so long to see you back again. Would love to hear the travelling stories of yours. Your or my place?</p>
              <div class="add">
           	<img src="images/unlike.svg" onclick="changeImg1()" id="myImg1">
           <span onclick="onButtonClick2()">Reply</span>
           <form action="index.php" method="post">

           	<div  class="hide" id="textInput2" >

           <input  type="text" name="comment" class="commentt"   placeholder="Write Your Comment">
           <button class="submit" type="submit" name="submit"><img  src="images/send.svg"></button>
           </div>
           </div>

           </form>
       </div></div>

        <div class="col-md-6 trd_comment" onclick="onButtonClick8()">
       	<img class="float" src="images/user3.png">
       	<div class="handler">
       	<h4>Alex Benjiman</h4>
       	   <p>Home sweet home! I'm glad you are back. It's been two year and miss the football matches we have together. A lot has been changed since you left. Let's meet at the ground tomorrow evening?</p>
              <div class="add">
           	<img src="images/unlike.svg" onclick="changeImg2()" id="myImg2">
           <span onclick="onButtonClick3()">Reply</span>
           <form action="index.php" method="post">

           	<div  class="hide" id="textInput3" >

           <input  type="text" name="comment" class="commentt"   placeholder="Write Your Comment">
           <button class="submit" type="submit" name="submit"><img  src="images/send.svg"></button>
           </div>
           </div>

           </form>
       </div>
       </div>



	</div>  <!-- end row -->
</div><!-- end container -->

 <script type="text/javascript">
function changeImg() {
    var image = document.getElementById('myImg');
    if (image.src.match("images/like.svg")) {
        image.src = "images/unlike.svg";
    }
    else {
        image.src = "images/like.svg";
    }
}

function changeImg1() {
    var image = document.getElementById('myImg1');
    if (image.src.match("images/like.svg")) {
        image.src = "images/unlike.svg";
    }
    else {
        image.src = "images/like.svg";
    }
}

function changeImg2() {
    var image = document.getElementById('myImg2');
    if (image.src.match("images/like.svg")) {
        image.src = "images/unlike.svg";
    }
    else {
        image.src = "images/like.svg";
    }
}
</script>



 <script type="text/javascript">
function onButtonClick(){
  document.getElementById('textInput').className="show";
}

</script>
 <script type="text/javascript">
function onButtonClick2(){
  document.getElementById('textInput2').className="show";
}

</script>
 <script type="text/javascript">
function onButtonClick3(){
  document.getElementById('textInput3').className="show";
}

</script>


</body>
</html>